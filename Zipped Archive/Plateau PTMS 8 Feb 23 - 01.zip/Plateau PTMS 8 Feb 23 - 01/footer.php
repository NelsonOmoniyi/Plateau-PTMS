<!-- Footer strat -->
<footer class="footer">
			<div class="foo-btm">
				<div class="container">
					<div class="row">
						<div class="col-12">
							<div class="copyright">Copyright &copy; <a href="accessng.com"> Powered By Access Solutions LTD </a><?php echo " ".date("Y");?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</footer>
		<!-- Footer end -->

		<!-- JS -->
		<script src="js1/jquery-3.3.1.min.js"></script>
		<script src="js1/jquery-ui.min.js"></script>
		<script src="js1/bootstrap.min.js"></script>
		<script src="js1/owl.carousel.min.js"></script>
		<script src="js1/owl.carousel2.thumbs.min.js"></script>
		<script src="js1/jquery.countdown.min.js"></script>
		<script src="js1/jquery.fancybox.min.js"></script>
		<script src="js1/jquery.nice-select.min.js"></script>
		<script src="js/dsp.js"></script>
		<script src="js1/scripts.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>

		</body>

</html>